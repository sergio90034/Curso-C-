#include "CommandBase.h"

CommandBase::CommandBase(Canvas &canvas) : receiver(canvas) {}


