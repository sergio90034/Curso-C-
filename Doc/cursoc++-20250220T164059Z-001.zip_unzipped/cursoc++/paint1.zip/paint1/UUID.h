#ifndef UUID_H
#define UUID_H

#include <string>

std::string generateUUID();

#endif // UUID_H
